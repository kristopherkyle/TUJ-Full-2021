# Day 3: More data analysis; Lexical richness as a multivariate construct

#First, we will load important libraries:
#install.packages("ggplot2")
library(ggplot2) #visualizations

#Second, we will load our data spreadsheet
written_data <- read.csv("icnale_rubric_taaled_taales_20210618_simple.csv", header = TRUE)

#Third, we will get descriptive statistics for the dataset:
summary(written_data) #one participant omitted due to data issue

#create dataframe with only variables that have numeric variables:

written_data_num <- written_data[, -c(1,2,3,4,5)] #exclude categorical variables
summary(written_data_num) # Check to make sure only numeric variables remain

#create correlation matrix
corr_matrix <- cor(written_data_num) #create correlation matrix, call it "corr_matrix"
print(corr_matrix) #view correlation matrix (a little messy)

#write to a file for easier viewing (note, the top header will need to be shifted to the right one column):
write.table(corr_matrix,"correlation_matrix.csv",sep = ",")

#visualize correlations
#install.packages("ggcorrplot")
library(ggcorrplot)
ggcorrplot(corr_matrix) 

ggcorrplot(corr_matrix, type = "lower") #create heat map - a bit messy with small screen

#Task: 
#1. Choose two indices and indicate what the correlation between that index and vocabulary score is (and what it means) for each
#(check table OR run cor.test)
#example:
cor.test(written_data_num$vocabulary,written_data_num$mattr50_aw)
cor.test(written_data_num$vocabulary,written_data_num$mtld_original_aw)

#2. Determine whether the correlations are appropriate or not (are the relationships roughly linear?)
#(create scatterplot)
#example:
ggplot(written_data, aes(nwords,vocabulary)) +
  geom_jitter() + #this can be used instead of geom_point() to account for the limted scale of "vocabulary"
  geom_smooth(method = "loess",color = "red") + #this is a line of best fit based on a moving average
  geom_smooth(method = "lm") #this is a line of best fit based on the enture dataset

#3. Are the selected indices collinear?
cor.test(written_data_num$mattr50_aw,written_data_num$mtld_original_aw)

#4. If they are collinear, which one is more strongly related to vocabulary score?
#(see #1)


#Next steps: Conduct Multiple Regression

# Multiple regression:
#lm(to_predict ~ var1 + var2 + var3, data = dataframe_name)
mult_reg1 <- lm(vocabulary ~ mattr50_aw + SUBTLEXus_Freq_Log_CW, data = written_data)
summary(mult_reg1)

#To add a column to our dataframe, we just define it
written_data$pred_Score1 <- predict(mult_reg1)
#We can use summary() to make sure it worked correctly
summary(written_data_num)

#plot data:
ggplot(written_data, aes(pred_Score1,vocabulary)) +
  geom_jitter() + #this can be used instead of geom_point() to account for the limted scale of "vocabulary"
  geom_smooth(method = "loess",color = "red") + #this is a line of best fit based on a moving average
  geom_smooth(method = "lm") #this is a line of best fit based on the enture dataset

#check for prompt differences:
ggplot(written_data, aes(pred_Score1,vocabulary)) +
  geom_jitter(aes(color = topic)) + #this can be used instead of geom_point() to account for the limted scale of "vocabulary"
  geom_smooth(method = "lm", aes(color = topic)) #this is a line of best fit based on the enture dataset


#now, lets work to build a better model!
#for now, choose four variables that are not collinear and build a model


#finally, lets use a stepwise method to optimize our model
install.packages("MASS")
library(MASS)
stepwise_model <- stepAIC(mult_reg1, direction="both")

summary(stepwise_model) #in this case, both of our variables were retained

#now, check your model!
