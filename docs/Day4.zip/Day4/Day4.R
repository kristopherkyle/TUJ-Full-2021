# Day 4: Building multivariate models of lexical sophistication

#Step 1 - Make sure system is set up appropriately:
Sys.setenv(LANG = "en")
Sys.setlocale("LC_ALL", "C")

#Step 2 - Load packages:
#install.packages("ggplot2")
library(ggplot2) #visualizations

#Step 3 - Load data:
written_data <- read.csv("icnale_rubric_taaled_taales_20210619_simple.csv", header = TRUE)
summary(written_data) #one participant omitted due to data issue

#Step 4 - Check each variable for linearity:
#this is a sample - do for each index (copy/paste then replace variable name)
ggplot(written_data, aes(mattr50_aw,vocabulary)) +
  geom_jitter() + #this can be used instead of geom_point() to account for the limted scale of "vocabulary"
  geom_smooth(method = "loess",color = "red") + #this is a line of best fit based on a moving average
  geom_smooth(method = "lm") #this is a line of best fit based on the enture dataset

#Step 5 - Prepare data for correlation matrix
#Method 1: Use column numbers
written_data_num <- written_data[, -c(1,2,3,4)] #exclude categorical variables

#Method 2: Use variable names with the package dplyr()
#install.packages("dplyr")
library(dplyr)
written_data_num <- dplyr::select(written_data, -filename,-participant,-country,-topic)

#Step 6 - Check for collinearity using a correlation matrix
corr_matrix <- cor(written_data_num)
View(corr_matrix)

#Step 7 - Examine correlation matrix, select variables based criteria:

#a. Remove any variables that demonstrate a negligible relationship with vocabulary score (|r| < .100)
# - COCA_magazine_Bigram_Lemma_Frequency_Log (bigram frequency)
# - COCA_lemma_magazine_bi_prop_90k (bigram frequency)

#b. For each conceptual category, check for multicollinearity (|r| > .700).

#c. For any collinear pairs, choose index with strongest theoretical rationale OR strongest correlation with vocabulary score
# to delete:
# - mtld_original_aw (lexical diversity)
# - COCA_magazine_lemma_frequency_Log_CW (word frequency)
# - LD_Mean_RT_CW (lexical access)

#Step 8 - Create refined dataset by removing variables identified in Step 7 and double check collinearity across conceptual categories
#a. create refined dataset
written_data_refined1 <- dplyr::select(written_data, -nwords, -mtld_original_aw,-COCA_magazine_lemma_frequency_Log_CW,-COCA_magazine_Bigram_Lemma_Frequency_Log,-COCA_lemma_magazine_bi_prop_90k,-LD_Mean_RT_CW)

#b. Remove categorical variables from refined dataset, check correlation matrix
written_data_refined1_num <- dplyr::select(written_data_refined1, -filename,-participant,-country,-topic)
corr_matrix_refined <- cor(written_data_refined1_num)
View(corr_matrix_refined)

#Step 9 - Recheck multicollinearity
#a. Model optimization approach - choose variable with strongest correlation (with vocabulary score), then remove any collinear variables (|r| > .700)
#  - start with Kuperman_AoA_CW (Age of acquisition/exposure)
#Then, continue with variable next strongest correlation (etc.)


#b. Conceptual approach - choose most theoretically/conceptually important variable, then remove any collinear variables (|r| > .700)
# - start with SUBTLEXus_Freq_Log_CW (frequency)? 
#Then, continue with second most theoretically/conceptually important variable (etc.)

# Step 10 - Refine dataset again (I used the model optimization approach)
written_data_refined2 <- dplyr::select(written_data_refined1, -SUBTLEXus_Freq_Log_CW,-WN_Mean_RT_CW)
summary(written_data_refined2)

# Step 11 - Run multiple regression
## Option 1 - Simple multiple regression (easy to run, results likely inflated)
#run model
model1 <- lm(vocabulary ~ mattr50_aw + COCA_lemma_magazine_bi_MI + Brysbaert_Concreteness_Combined_CW + Kuperman_AoA_CW + USF_CW_CW + McD_CD_CW, data = written_data_refined2)
summary(model1)
print(car::vif(model1)) #checks multicollinearity within model rule of thumb: vif < 5 is OK
#install.packages('relaimpo')
relaimpo::calc.relimp(model1) #gets relative importance metrics for model variables

## Option 2 - Training/Test sets
set.seed(123) # for reproducible results (seed is for random number generator)
sample.size <- floor(0.75 * nrow(written_data_refined2)) #get number of rows for 75% of data
train.index <- sample(seq_len(nrow(written_data_refined2)), size = sample.size) #get random list of rows (75% of the data)
train <- written_data_refined2[train.index, ] #training set
test <- written_data_refined2[- train.index, ] #test set

#create model with train set
model2.train <- lm(vocabulary ~ mattr50_aw + COCA_lemma_magazine_bi_MI + Brysbaert_Concreteness_Combined_CW + Kuperman_AoA_CW + USF_CW_CW + McD_CD_CW, data = train)
summary(model2)
print(car::vif(model2))
print(relaimpo::calc.relimp(model2)) #gets relative importance metrics for model variables


#test model on test set
test$pred1 <- predict(model2.train, test)
cor(test$vocabulary,test$pred1)^2 #get R^2

#Option 3: Cross-validation (Ten-fold)
install.packages("caret")
library(caret)
ctrl.tenfold <- trainControl(method="cv", number=10) #create method

model3 <- train(vocabulary ~ mattr50_aw + COCA_lemma_magazine_bi_MI + Brysbaert_Concreteness_Combined_CW + Kuperman_AoA_CW + USF_CW_CW + McD_CD_CW, data = written_data_refined2, method = "lm", trControl = ctrl.tenfold)
summary(model3) #show full model
print(model3) #show cross-validated results


#Option 4: Cross-validation (LOOCV)

ctrl.loocv <- trainControl(method = "LOOCV") #create method

model4 <- train(vocabulary ~ mattr50_aw + COCA_lemma_magazine_bi_MI + Brysbaert_Concreteness_Combined_CW + Kuperman_AoA_CW + USF_CW_CW + McD_CD_CW, data = written_data_refined2, method = "lm", trControl = ctrl.loocv)
summary(model4) #show full model
print(model4) #show cross-validated results

